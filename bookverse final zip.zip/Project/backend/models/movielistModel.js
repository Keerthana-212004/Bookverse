const mongoose = require("mongoose");
const movielistSchema = new mongoose.Schema({
  movie: {
    type: String,
    required: true,
  },
  image: {
    type: String,
    required: true,
  },
  description: {
    type: String,
  },
  details: {
    type: String,
    required: true,
  },
  cast: [
    {
      name: {
        type: String,
        required: true,
      },
      nickname: {
        type: String,
      },
      image: {
        type: String,
        required: true,
      },
    },
  ],
  crew: [
    {
      name: {
        type: String,
        required: true,
      },
      nickname: {
        type: String,
      },
      image: {
        type: String,
        required: true,
      },
    },
  ],
});

module.exports = mongoose.model("movielist", movielistSchema);
