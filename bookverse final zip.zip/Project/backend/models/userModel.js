const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const userSchema = new mongoose.Schema({
  userName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    required: true,
  },
});

userSchema.methods.isValidatePassword = function (enPassword) {
  return bcrypt.compare(enPassword, this.password);
};

module.exports = mongoose.model("user", userSchema);
