const express = require("express");
const {
  register,
  login,
  verifyToken,
  getAllMovies,
  getMovie,
  getAllTickets,
  saveTicket,
  changePassword,
  saveMovie,
  deleteMovie,
} = require("../controllers/userController");
const router = express.Router();

router.route("/user/register").post(register);
router.route("/user/login").post(login);
router.route("/user/verify").get(verifyToken);
router.route("/user/getallmovies").get(getAllMovies);
router.route("/user/getalltickets").get(getAllTickets);
router.route("/user/saveticket").post(saveTicket);
router.route("/user/savemovie").post(saveMovie);
router.route("/user/changepassword").post(changePassword);
router.route("/user/deletemovie/:id").delete(deleteMovie);
router.route("/user/getmovie/:id").get(getMovie);

module.exports = router;
