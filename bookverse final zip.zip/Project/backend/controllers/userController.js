const userModel = require("../models/userModel");
const ticketModel = require("../models/ticketModel");
const Movielist = require("../models/movielistModel");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

exports.register = async (req, res) => {
  const { userName, email, password, role } = req.body;
  const validUser = await userModel.findOne({ email: email });
  const hPassword = await bcrypt.hash(password, 10);

  if (validUser) {
    return res.status(400).json({
      success: false,
      message: "User already registered",
    });
  } else {
    const user = await userModel.create({
      userName,
      email,
      password: hPassword,
      role,
    });
    res.status(200).json({
      success: true,
      message: "User Registered Successfully",
    });
  }
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  console.log(req.body);
  const validUser = await userModel.findOne({ email: email });
  if (!validUser) {
    return res.status(401).json({
      success: false,
      message: "Invalid Credentials",
    });
  }
  if (!(await validUser.isValidatePassword(password))) {
    return res.status(401).json({
      success: false,
      message: "Invalid Credentials",
    });
  }
  const token = jwt.sign(
    {
      id: validUser._id,
      email: validUser.email,
      userName: validUser.userName,
      role: validUser.role,
    },
    process.env.JWT_SECRET,
    {
      expiresIn: "1d",
    }
  );

  res.status(200).json({
    success: true,
    role: validUser.role,
    message: "Login Successful",
    token,
  });
};

exports.verifyToken = (req, res) => {
  const token = req.headers.authorization;

  if (!token) {
    return res
      .status(401)
      .json({ success: false, message: "No token provided" });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid or expired token" });
    }

    res
      .status(200)
      .json({ success: true, message: "Token is valid", user: decoded });
  });
};
exports.getAllMovies = async (req, res) => {
  const getAllMovie = await Movielist.find({});

  if (!getAllMovie) {
    return res.status(400).json({ success: false, message: "No Movies Found" });
  }

  res.status(200).json({ success: true, movies: getAllMovie });
};
exports.getAllTickets = async (req, res) => {
  const getAllMovie = await ticketModel.find({});
  if (!getAllMovie) {
    return res.status(400).json({ success: false, message: "No Movies Found" });
  }

  res.status(200).json({ success: true, tickets: getAllMovie });
};

exports.getMovie = async (req, res) => {
  try {
    const movie = await Movielist.findById(req.params.id);
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" });
    }
    res.status(200).json({ success: true, movie });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

exports.saveTicket = async (req, res) => {
  const { title, price, date, time, image, theatre, userName, selectedSeats } =
    req.body;

  const user = await ticketModel.create({
    title,
    price,
    userName,
    date,
    time,
    image,
    selectedSeats,
    theatre,
  });
  res.status(200).json({
    success: true,
    message: "Ticket Saved Successfully",
  });
};

exports.changePassword = async (req, res) => {
  try {
    const { password, newPassword, token } = req.body;
    console.log(req.body);
    // 🔹 Verify JWT Token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (!decoded) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid or expired token" });
    }

    // 🔹 Find the user by email
    const user = await userModel.findOne({ email: decoded.email });
    if (!user) {
      return res
        .status(401)
        .json({ success: false, message: "User not found" });
    }

    // 🔹 Check if the current password is correct
    const isPasswordCorrect = await bcrypt.compare(password, user.password);
    if (!isPasswordCorrect) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid current password" });
    }

    // 🔹 Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // 🔹 Update the password
    await userModel.findOneAndUpdate(
      { email: decoded.email },
      { password: hashedPassword }
    );

    return res.status(200).json({
      success: true,
      message: "Password Updated Successfully",
    });
  } catch (error) {
    console.error("Error changing password:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server Error" });
  }
};
exports.saveMovie = async (req, res) => {
  const { movie, description, image, cast, crew } = req.body;

  const user = await Movielist.create({
    movie,
    details: description,
    image,
    cast,
    crew,
  });
  res.status(200).json({
    success: true,
    message: "Movie Saved Successfully",
  });
};
exports.deleteMovie = async (req, res) => {
  const { id } = req.params;
  const user = await Movielist.findOneAndDelete({ _id: id });
  res.status(200).json({
    success: true,
    message: "Movie Deleted Successfully",
  });
};
