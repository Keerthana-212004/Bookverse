const express = require("express");
const app = express();
const dotenv = require("dotenv");
const path = require("path");
const fs = require("fs");
const cors = require('cors');
const mongoose = require("mongoose");
const UserRoute = require("./routes/userRoute");

dotenv.config();
const port = process.env.PORT || 5000;
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}
app.use(cors({ origin: 'http://localhost:8080' }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(uploadDir));
app.use("/api/v1", UserRoute);

// app.use("/api/v1", invoice);
// app.use("/api/v1", client);
// app.use("/api/v1", pdf);
// app.use("/api/v1", business);

mongoose.connect(process.env.MONGO_URI).then(()=>{
    console.log("Mongodb Connected")
})
app.listen(port,()=>{
    console.log(`Server up and running on port ${port}`)
})