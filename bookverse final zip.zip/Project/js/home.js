document.querySelectorAll(".menu-item").forEach((item) => {
  item.addEventListener("click", (event) => {
    let submenu = item.querySelector(".submenu");
    if (submenu) {
      submenu.computedStyleMap.display =
        submenu.computedStyleMap.display === "block" ? "none" : "block";
    }
  });
});

//sidenavbar
let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides((slideIndex += n));
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  if (n > slides.length) {
    slideIndex = 1;
  }
  if (n < 1) {
    slideIndex = slides.length;
  }
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slides[slideIndex - 1].style.display = "block";
}

/* search box */

var productContainer = document.getElementById("movies");
var search = document.getElementById("search");
var productlist = productContainer.querySelectorAll("div");

search.addEventListener("keyup", function () {
  var enteredValue = event.target.value.toUpperCase();
  for (count = 0; count < productlist.length; count = count + 1) {
    var productname = productlist[count].querySelector("p").textContent;

    if (productname.toUpperCase().indexOf(enteredValue) < 0) {
      productlist[count].style.display = "none";
    } else {
      productlist[count].style.display = "block";
    }
  }
});

let subMenu = document.getElementById("subMenu");

function toggleMenu() {
  subMenu.classList.toggle("open_menu");
}
    