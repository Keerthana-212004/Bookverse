// Rating Button Hover
const rateBtn = document.querySelector('.rate-btn');
rateBtn.addEventListener('mouseover', () => {
    rateBtn.style.background = 'green';
    rateBtn.style.color = 'white';
});
rateBtn.addEventListener('mouseout', () => {
    rateBtn.style.background = 'white';
    rateBtn.style.color = 'black';
});

// Book Ticket Button Click Alert
const bookBtn = document.querySelector('.book-btn');
bookBtn.addEventListener('click', () => {
    alert('Redirecting to ticket booking...');
});

// Book Tickets Button Click
document.querySelector(".book-btn").addEventListener("click", () => {
    alert("Redirecting to ticket booking...");
});

// Review Like Animation (Example Effect)
document.querySelectorAll(".likes").forEach(like => {
    like.addEventListener("click", () => {
        like.style.color = "blue";
    });
});