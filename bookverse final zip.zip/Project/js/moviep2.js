const seats = document.querySelectorAll('.seat.available');
const selectedSeats = new Set(JSON.parse(sessionStorage.getItem('selectedSeats')) || []);
const seatPrice = 150; // Example price per seat
const totalPriceElement = document.getElementById('total-price');
const payButton = document.getElementById('pay-btn');
function closeModal() {
  const modal = document.getElementById("seatModal");
  modal.style.display = "none";
}
// Highlight seats already in sessionStorage and update total
seats.forEach(seat => {
    const row = seat.parentElement.querySelector('span')?.textContent || ''; // Fallback if null
    const seatNumber = seat.textContent || ''; // Fallback if null
    const seatInfo = row && seatNumber ? `${row}${seatNumber}` : ''; // Only combine if both exist

    if (seatInfo && selectedSeats.has(seatInfo)) {
        seat.classList.add('selected');
    }

    // Add click event for seat selection
    seat.addEventListener('click', () => toggleSeat(seat, seatInfo));
});

// Toggle seat selection and update UI
function toggleSeat(seat, seatInfo) {
    if (!seatInfo) return; // Don’t toggle if seatInfo is empty

    if (selectedSeats.has(seatInfo)) {
        selectedSeats.delete(seatInfo);
        seat.classList.remove('selected');
    } else {
        selectedSeats.add(seatInfo);
        seat.classList.add('selected');
    }

    updateSeatInfo();
    saveToSessionStorage();
    updateTotal(); // Make sure price updates after seat selection
}

// Update seat info log
function updateSeatInfo() {
    const seatCount = selectedSeats.size;
    const seatList = [...selectedSeats];

    console.log(`Seats selected: ${seatCount}`);
    console.log(`Selected seats: ${seatList.join(', ')}`);
}

// Save selected seats to sessionStorage
function saveToSessionStorage() {
    sessionStorage.setItem('selectedSeats', JSON.stringify([...selectedSeats]));
}

// Update total price and pay button
function updateTotal() {
    const totalPrice = selectedSeats.size * seatPrice;
    totalPriceElement.innerText = `Rs. ${totalPrice}`;
    sessionStorage.setItem('price',totalPrice);
    payButton.innerText =
        totalPrice > 0 ? `Pay Rs. ${totalPrice}` : "Select seats to proceed";
}

function navigate() {
  if(selectedSeats.size > 0){
    window.location.href = '/html/demo.html'
  }else{
    alert('Please Select Seats')
  }
  
}
// Show seat info from sessionStorage on page load and update total price
function showStoredSeats() {
    const storedSeats = JSON.parse(sessionStorage.getItem('selectedSeats')) || [];
    const filteredSeats = storedSeats.filter(seat => seat); // Remove empty strings/nulls
    console.log(`Stored Seats: ${filteredSeats.length}`);
    console.log(`Stored Seat Numbers: ${filteredSeats.join(', ')}`);
    
    updateTotal(); // Update total when page loads with already selected seats
}

// Call on page load
showStoredSeats();
