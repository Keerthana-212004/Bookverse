// Date Selector Click Event
document.querySelectorAll(".date").forEach(date => {
    date.addEventListener("click", () => {
        document.querySelectorAll(".date").forEach(d => d.classList.remove("active"));
        date.classList.add("active");
    });
});

// Show Timing Button Click
document.querySelectorAll(".times button").forEach(button => {
    button.addEventListener("click", () => {
        alert('You selected show!');
    });

});
