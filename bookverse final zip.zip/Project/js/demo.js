// Function to toggle donation amount
function toggleDonation() {
    let totalElement = document.getElementById("totalPrice");
    let finalElement = document.getElementById("finalPrice");
    let donationText = document.querySelector(".donate-option");

    let currentTotal = parseFloat(totalElement.innerText.replace("₹", ""));
    
    if (donationText.innerText === "Add ₹2.00") {
        totalElement.innerText = `₹${(currentTotal + 2).toFixed(2)}`;
        finalElement.innerText =`₹${(currentTotal + 2).toFixed(2)}`;
        donationText.innerText = "Remove ₹2.00";
    } else {
        totalElement.innerText = `₹${(currentTotal - 2).toFixed(2)}`;
        finalElement.innerText = `₹${(currentTotal - 2).toFixed(2)}`;
        donationText.innerText = "Add ₹2.00";
    }
}