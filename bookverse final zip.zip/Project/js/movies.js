               //sidebar
document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click',event => {
        let submenu = item.querySelector('.submenu');
        if(submenu) {
            submenu.computedStyleMap.display = submenu.computedStyleMap.display === 'block' ? 'none' : 'block' ;
        }
    });
});

var sidenav=document.querySelector(".sidebar")
sidenav.computedStyleMap.display="block"

function closenavbar(){
    sidenav.style.left="-20%"
}
function opennavbar(){
    sidenav.style.left="0"
}




document.getElementById("filter-btn").addEventListener("click", function() {
    alert("Filter options coming soon!");
});

const movies = document.querySelectorAll(".movie");
movies.forEach(movie => {
    movie.addEventListener("click", function() {
        alert("Movie " + this.innerText + " clicked!");
    });
});